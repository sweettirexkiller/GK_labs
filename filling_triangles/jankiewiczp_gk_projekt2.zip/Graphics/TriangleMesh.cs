using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Numerics;
using filling_triangles.Geometry;

namespace filling_triangles.Graphics;


public class Surface
{
    private double _kd;
    private double _ks;
    private double _m;

    public double Kd { get => _kd; set => _kd = value; }
    public double Ks { get => _ks; set => _ks = value; }
    public double M { get => _m; set => _m = value; }

    public Surface(double kd, double ks, double m)
    {
        _ks = kd;
        _kd = ks;
        _m = m;
    }
}
public class TriangleMesh
{
    public List<Face> Faces { get; set;}
    public List<Vertex> Vertices { get; set; }

    private int _columnsCountX;
    private int _rowsCountY;
    private int _width;
    private int _height;
    public int _xSpan;
    public int _ySpan;
    public readonly int _offset = 10;
    public Color ObjectColor;
    public bool IsColorFilled = true;
    public bool IsTextureFilled = false;
    
    public DirectBitmap _textureBitmap;
    public NormalBitMap _normalBitMap;

    public bool IsNormalMap = false;
    public bool IsConstantNormalVector = false;
    
    public int Width
    {
        get => _width;
        set => _width = value;
    }
    
    public int Height
    {
        get => _height;
        set => _height = value;
    }

    public int ColumnsCountX
    {
        get => _columnsCountX;
        set => _columnsCountX = value;
    }

    public int RowsCountY
    {
        get => _rowsCountY;
        set => _rowsCountY = value;
    }

    public bool IsMeshVisible { get; set; }
    public Color LightColor { get; set; }
    public bool IsColorInterpolated { get; set; }
    public bool IsLightConstant { get; set; }
    public bool IsLightAnimated { get; set; }
    
    public Surface Surface { get; set; }
    public Image Image { get; set; }
    public bool IsFunctionalZ { get; set; }
    public bool ShouldRotateOnce { get; set; }
    public double AlfaForZRotation { get; set; }
    public double BetaForXRotation { get; set; }

    public TriangleMesh(int columnsCountX, int rowsCountY, int width, int height, Color objectColor)
    {
        Vertices = new List<Vertex>();
        Faces = new List<Face>();
        _columnsCountX = columnsCountX;
        _rowsCountY = rowsCountY;
        _width = width;
        _height = height;
        ObjectColor = objectColor;
        IsMeshVisible = true;
        Surface = new Surface(0.5, 0.5, 50);
        _textureBitmap = new DirectBitmap(width,height);
        IsLightAnimated = true;
        IsLightConstant = true;
        IsColorInterpolated = false;
        ShouldRotateOnce = false;

        GenerateTriangles();
    }

    public double ZFunction(double x, double y)
    {
        if (IsFunctionalZ)
        {
            return  (Math.Sin(Math.PI/2.0 *x/_xSpan) + Math.Cos(Math.PI/2.0*y/_ySpan));
        }
        else
        {
            return 0;
        }
        
    }

    public void GenerateTriangles()
    {
        Vertices = new List<Vertex>();
        Faces = new List<Face>();
        // find triangles mesh vertices, faces;
        double x = _offset;
        double y = _offset;
        double stepX = (_width - 2*_offset) / ColumnsCountX; // lenght of base of a triange
        double stepY = (_height - 2*_offset) / RowsCountY; // height of a triangle
        _xSpan = (int)stepX*ColumnsCountX;
        _ySpan = (int)stepY*RowsCountY;
        
      
        // create a list of active edges
        for (int i = 1; i <= _columnsCountX; i++)
        {
            for (int j = 1; j <= _rowsCountY; j++)
            {
                // points
                Point3D upperLeft, upperRight, downLeft, downRight;
                
                
                if (IsFunctionalZ)
                {
                    upperLeft = new Point3D(x, y, this.ZFunction(x,y)); // upper left
                    upperRight = new Point3D(x + stepX, y,  this.ZFunction(x+stepX,y)); // upper right
                    downLeft = new Point3D(x, y + stepY,  this.ZFunction(x,y+stepY)); // down left
                    downRight = new Point3D(x + stepX, y + stepY, this.ZFunction(x+stepX, y+stepY)); // down right
                }
                else
                {
                    // use beziere 
                    upperLeft = new Point3D(x, y, 0); // upper left
                    upperRight = new Point3D(x + stepX, y, 0); // upper right
                    downLeft = new Point3D(x, y + stepY, 0); // down left
                    downRight = new Point3D(x + stepX, y + stepY, 0); // down right
                }
                
                List<Point3D> points = new List<Point3D>{upperLeft, upperRight, downLeft, downRight};

                // if (ShouldRotateOnce)
                // {
                //     foreach (Point3D point in points)
                //     {
                //       
                //         if (AlfaForZRotation != 0)
                //         {
                //            
                //             //1. translate to origin
                //             x = x - Width / 2;
                //             y = y - Height / 2;
                //             //2. rotate
                //             x = (int)(x*Math.Cos(AlfaForZRotation) - y*Math.Sin(AlfaForZRotation));
                //             y = (int)(x*Math.Sin(AlfaForZRotation) + y*Math.Cos(AlfaForZRotation));
                //             //3. translate back
                //             x = x + Width / 2;
                //             y = y + Height / 2;
                //                     
                //         }
                //
                //         if (BetaForXRotation != 0)
                //         {
                //             // 1. translate to origin
                //             x = x - Width / 2;
                //             y = y - Height / 2;
                //             // 2. rotate
                //             y = (int)(y * Math.Cos(BetaForXRotation) - ZFunction(x, y) * Math.Sin(BetaForXRotation));
                //             x = (int)(y * Math.Sin(BetaForXRotation) + ZFunction(x, y) * Math.Cos(BetaForXRotation));
                //             // 3. translate back
                //             x = x + Width / 2;
                //             y = y + Height / 2;
                //         }
                //        
                //     }
                //
                // }
              

                // UPPER TRIANGLE
                // calculate upper triangle normal vector
                Vector3 upperTriangleNormal = CalculateTriangleNormal(upperLeft, upperRight, downLeft);
                // create vertices for upper triangle
                Vertex upperLeftVertex = new Vertex(upperLeft, i*10+j+1,upperTriangleNormal);
                Vertex upperRightVertex = new Vertex(upperRight, i*10+j+2,upperTriangleNormal);
                Vertex downLeftVertex = new Vertex(downLeft, i*10+j+3,upperTriangleNormal);


                // LOWER TRIANGLE
                // calculate lower triangle normal vector
                Vector3 lowerTriangleNormal = CalculateTriangleNormal(downLeft, upperRight, downRight );
                // create vertices for lower triangle
                Vertex downRightVertex = new Vertex(downRight, i*10+j+4,lowerTriangleNormal);
                Vertex upperRightVertex2 = new Vertex(upperRight, i*10+j+5,lowerTriangleNormal);
                Vertex downLeftVertex2 = new Vertex(downLeft, i*10+j+6,lowerTriangleNormal);
                
                // create lower triangle face
                Face lowerTriangle = new Face(new List<Vertex>{downRightVertex, upperRightVertex2, downLeftVertex2});
                // create upper triangle face
                Face upperTriangle = new Face(new List<Vertex>{upperLeftVertex, upperRightVertex, downLeftVertex});
                
        
                // add these two triangels to the list of faces
                Faces.Add(lowerTriangle);
                Faces.Add(upperTriangle);
                
                // add vertices to the list
                Vertices.Add(upperLeftVertex);
                Vertices.Add(upperRightVertex);
                Vertices.Add(downLeftVertex);
                Vertices.Add(downRightVertex);
                Vertices.Add(upperRightVertex2);
                Vertices.Add(downLeftVertex2);

                y += stepY;

            }
            x += stepX;
            y = _offset;

        }
        
        
        ShouldRotateOnce = false;
        
       
    }
    
    // this function calculates normal vector for a triangle
    static Vector3 CalculateTriangleNormal(Point3D A, Point3D B, Point3D C)
    {
        // Wektor AB
        Vector3 AB = B - A;
        // Wektor AC
        Vector3 AC = C - A;
        // Wektor normalny
        Vector3 normalVector = Vector3.Cross(AB, AC);

        // Normalizacja wektora normalnego
        normalVector = Vector3.Normalize(normalVector);

        return normalVector;
    }
    public void DrawAllEdges(DirectBitmap canvas)
    {
       //draw all edges in all faces
       using (System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(canvas.Bitmap))
         foreach (var face in Faces)
         {
              foreach (var edge in face.Edges)
              {
                  // if (ShouldRotateOnce)
                  // {
                  //     X = X - triangleMesh.Width / 2;
                  //     Y = Y - triangleMesh.Height / 2;
                  //                   
                  //     if (triangleMesh.AlfaForZRotation != 0.0)
                  //     {
                  //         //2. rotate
                  //         X = (int)(X*Math.Cos(triangleMesh.AlfaForZRotation) - Y*Math.Sin(triangleMesh.AlfaForZRotation));
                  //         X = (int)(X*Math.Sin(triangleMesh.AlfaForZRotation) + Y*Math.Cos(triangleMesh.AlfaForZRotation));
                  //     }
                  //     if (triangleMesh.BetaForXRotation != 0.0)
                  //     {
                  //         // 2. rotate
                  //         Y = (int)(Y * Math.Cos(triangleMesh.BetaForXRotation) - triangleMesh.ZFunction(X, Y) * Math.Sin(triangleMesh.BetaForXRotation));
                  //         X = (int)(Y * Math.Sin(triangleMesh.BetaForXRotation) + triangleMesh.ZFunction(x, Y) * Math.Cos(triangleMesh.BetaForXRotation));
                  //     }
                  //     //3. translate back
                  //     X = X + triangleMesh.Width / 2;
                  //     Y = Y + triangleMesh.Height / 2;
                  //     if (X >= triangleMesh._offset && X < (triangleMesh._offset + triangleMesh._xSpan) && Y >= triangleMesh._offset && Y < triangleMesh._offset + triangleMesh._ySpan)
                  //     {
                  //         canvas.SetPixel(X, Y,color);
                  //     }
                  //     else
                  //     {
                  //         canvas.SetPixel(X,Y , Color.White);
                  //     }
                  //     g.DrawLine(new Pen(Color.Black), (int)edge.V1.X, (int)edge.V1.Y, (int)edge.V2.X, (int)edge.V2.Y);
                  // }
                  // else
                  // {
                      
                      g.DrawLine(new Pen(Color.Black), (int)edge.V1.X, (int)edge.V1.Y, (int)edge.V2.X, (int)edge.V2.Y);
                  // }
              }
         }
    }

    public void Paint(Brush brush, DirectBitmap canvas, Lamp lamp)
    {
        foreach (var face in Faces)
        {
            brush.FillTriangle(this, face, canvas, lamp);
        }
        
        if(IsMeshVisible)
            DrawAllEdges(canvas);
    }

    public void SetTexture(Bitmap newTexture)
    {
        _textureBitmap = new DirectBitmap(newTexture);
    }
    
    public void SetTexture(Color color)
    {
        var oldTexture = _textureBitmap;
        _textureBitmap = new DirectBitmap(oldTexture.Width, oldTexture.Height);
        for (var i = 0; i < _textureBitmap.Width; i++)
        {
            for (var j = 0; j < _textureBitmap.Height; j++)
            {
                _textureBitmap.SetPixel(i, j, color);
            }
        }
        // _textureImage = Image.FromHbitmap(_textureBitmap.GetHbitmap());
    }
    
    
    public void SetNormalMap(Image newNormalMapImage)
    {
        var oldNormalMap = _normalBitMap;
        if(oldNormalMap is not null)
        {
            _normalBitMap = new NormalBitMap(newNormalMapImage, new Size(oldNormalMap.Width, oldNormalMap.Height));
        }
        else
        {
            _normalBitMap = new NormalBitMap(newNormalMapImage, new Size(Width, Height));
        }
    }
}