namespace filling_triangles.Geometry;

static class GeometryUtils
{
 
        public const double Eps = 1e-8;
        public const double Infinity = 1 / Eps;
}